package net.lawaxi.anticheat.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {

	@Shadow public abstract boolean equals(Object o);

	@Inject(at = @At("HEAD"), method = "updatePosition")
	private void boatfly(CallbackInfo info) {

		ClientPlayerEntity player = MinecraftClient.getInstance().player;

		if(this.equals(player))
		{
			Entity boat = player.getRootVehicle();
			if(boat!=null)
			{
				if(MinecraftClient.getInstance().options.keyJump.isPressed())
				{
                    boat.setVelocity(new Vec3d(boat.getVelocity().x, 0.3, boat.getVelocity().z));
				}
			}
		}
	}

}
